﻿using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyCompany("Avectra, Inc.")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCopyright("© Avectra, Inc.  All rights reserved.")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyDescription("")]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
[assembly: AssemblyProduct("netFORUMEP")]
[assembly: AssemblyTitle("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyVersion("2009.1.0.19348")]
[assembly: CompilationRelaxations(8)]
[assembly: RuntimeCompatibility(WrapNonExceptionThrows=true)]
